import { test, expect } from "@playwright/test";

test("E2E-001 - application is reachable @smoke", async ({ page }) => {
  const response = await page.goto("/", { waitUntil: "domcontentloaded" });

  expect(response).not.toBeNull();
  expect(response!.ok()).toBeTruthy();
});
