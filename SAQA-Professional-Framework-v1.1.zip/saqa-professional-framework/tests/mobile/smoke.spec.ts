import { test } from "@playwright/test";
import { MobileDriver } from "../../src/mobile/MobileDriver.js";

test.describe("Mobile Smoke", () => {
  test("MOB-001 - mobile driver can create a session", async () => {
    test.skip(
      !process.env.RUN_MOBILE,
      "Set RUN_MOBILE=true and configure Appium/device variables to run mobile tests."
    );

    const driver = new MobileDriver();

    try {
      await driver.start();
      const client = driver.getClient();
      const title = await client.getTitle();
      console.log(`Mobile session title: ${title}`);
    } finally {
      await driver.stop();
    }
  });
});
