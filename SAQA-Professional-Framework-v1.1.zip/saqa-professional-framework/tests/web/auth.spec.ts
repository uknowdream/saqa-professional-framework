import { test, expect } from "@playwright/test";
import { LoginPage } from "../../src/web/pages/LoginPage.js";

test.describe("Authentication", () => {
  test("AUTH-001 - valid login @smoke @regression", async ({ page }) => {
    const username = process.env.TEST_USERNAME;
    const password = process.env.TEST_PASSWORD;

    test.skip(!username || !password, "TEST_USERNAME and TEST_PASSWORD are required.");

    const loginPage = new LoginPage(page);

    await loginPage.open();
    await loginPage.login(username!, password!);
    await loginPage.expectLoginSuccess();

    await expect(page).toHaveURL(/dashboard/i);
  });
});
