import { test, expect } from "../../src/fixtures/test.js";

test.describe("API Health", () => {
  test("API-001 - health endpoint @smoke", async ({ api }) => {
    const response = await api.get("/health");
    expect(response.ok()).toBeTruthy();
  });
});
