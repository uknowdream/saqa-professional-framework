import tseslint from "typescript-eslint";

export default tseslint.config(
  {
    ignores: [
      "node_modules/**",
      "dist/**",
      "reports/**",
      "test-results/**"
    ]
  },
  ...tseslint.configs.recommended
);
