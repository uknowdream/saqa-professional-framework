export class FrameworkError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly cause?: unknown
  ) {
    super(message);
    this.name = "FrameworkError";
  }
}

export class ConfigurationError extends FrameworkError {
  constructor(message: string, cause?: unknown) {
    super(message, "CONFIGURATION_ERROR", cause);
    this.name = "ConfigurationError";
  }
}

export class AutomationError extends FrameworkError {
  constructor(message: string, cause?: unknown) {
    super(message, "AUTOMATION_ERROR", cause);
    this.name = "AutomationError";
  }
}
