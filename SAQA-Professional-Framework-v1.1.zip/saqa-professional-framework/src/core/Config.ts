import { z } from "zod";

const envSchema = z.object({
  TEST_ENV: z.string().default("staging"),
  BASE_URL: z.string().url(),
  API_BASE_URL: z.string().url(),
  HEADLESS: z.string().default("true"),
  TEST_USERNAME: z.string().optional(),
  TEST_PASSWORD: z.string().optional(),
  APPIUM_HOST: z.string().url().default("http://127.0.0.1:4723"),
  APPIUM_PLATFORM: z.string().default("Android"),
  APPIUM_DEVICE_NAME: z.string().optional(),
  APPIUM_APP: z.string().optional()
});

export type Config = z.infer<typeof envSchema>;

export function getConfig(): Config {
  return envSchema.parse({
    TEST_ENV: process.env.TEST_ENV,
    BASE_URL: process.env.BASE_URL,
    API_BASE_URL: process.env.API_BASE_URL,
    HEADLESS: process.env.HEADLESS,
    TEST_USERNAME: process.env.TEST_USERNAME,
    TEST_PASSWORD: process.env.TEST_PASSWORD,
    APPIUM_HOST: process.env.APPIUM_HOST,
    APPIUM_PLATFORM: process.env.APPIUM_PLATFORM,
    APPIUM_DEVICE_NAME: process.env.APPIUM_DEVICE_NAME,
    APPIUM_APP: process.env.APPIUM_APP
  });
}
