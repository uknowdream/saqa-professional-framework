export async function retry<T>(
  operation: () => Promise<T>,
  options: {
    attempts: number;
    delayMs: number;
    shouldRetry?: (error: unknown) => boolean;
  }
): Promise<T> {
  let lastError: unknown;

  for (let attempt = 1; attempt <= options.attempts; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error;
      const retryable = options.shouldRetry?.(error) ?? true;

      if (!retryable || attempt === options.attempts) {
        throw error;
      }

      await new Promise(resolve => setTimeout(resolve, options.delayMs));
    }
  }

  throw lastError;
}
