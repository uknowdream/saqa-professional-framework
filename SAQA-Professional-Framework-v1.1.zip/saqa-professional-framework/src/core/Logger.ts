export type LogLevel = "debug" | "info" | "warn" | "error";

export class Logger {
  constructor(private readonly context = "SAQA") {}

  private write(level: LogLevel, message: string, meta?: unknown): void {
    const timestamp = new Date().toISOString();
    const suffix = meta === undefined ? "" : ` ${this.safe(meta)}`;
    console[level === "debug" ? "log" : level](
      `[${timestamp}] [${level.toUpperCase()}] [${this.context}] ${message}${suffix}`
    );
  }

  debug(message: string, meta?: unknown): void { this.write("debug", message, meta); }
  info(message: string, meta?: unknown): void { this.write("info", message, meta); }
  warn(message: string, meta?: unknown): void { this.write("warn", message, meta); }
  error(message: string, meta?: unknown): void { this.write("error", message, meta); }

  private safe(value: unknown): string {
    try {
      return JSON.stringify(value, (_, v) => {
        if (typeof v === "string" && /password|token|secret|authorization/i.test(String(_))) {
          return "***MASKED***";
        }
        return v;
      });
    } catch {
      return "[unserializable]";
    }
  }
}
