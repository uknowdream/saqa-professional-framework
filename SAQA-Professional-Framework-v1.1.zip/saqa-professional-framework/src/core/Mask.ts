const sensitiveKeys = [
  "password",
  "pass",
  "token",
  "access_token",
  "refresh_token",
  "client_secret",
  "authorization",
  "cookie"
];

export function maskSecrets(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(maskSecrets);

  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        sensitiveKeys.some(k => key.toLowerCase().includes(k))
          ? "***MASKED***"
          : maskSecrets(item)
      ])
    );
  }

  return value;
}
