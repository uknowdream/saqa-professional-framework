import { expect, type Locator, type Page } from "@playwright/test";

export abstract class BasePage {
  protected constructor(protected readonly page: Page) {}

  protected async click(locator: Locator, name: string): Promise<void> {
    await expect(locator, `${name} should be actionable`).toBeVisible();
    await locator.click();
  }

  protected async fill(locator: Locator, value: string, name: string): Promise<void> {
    await expect(locator, `${name} should be visible`).toBeVisible();
    await locator.fill(value);
  }

  protected async expectVisible(locator: Locator, name: string): Promise<void> {
    await expect(locator, `${name} should be visible`).toBeVisible();
  }
}
