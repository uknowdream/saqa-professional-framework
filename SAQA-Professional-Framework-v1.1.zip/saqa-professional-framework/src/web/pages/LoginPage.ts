import { expect, type Page } from "@playwright/test";
import { BasePage } from "../BasePage.js";

export class LoginPage extends BasePage {
  private readonly usernameInput;
  private readonly passwordInput;
  private readonly loginButton;
  private readonly dashboardMarker;

  constructor(page: Page) {
    super(page);
    this.usernameInput = page.getByLabel(/username|email/i);
    this.passwordInput = page.getByLabel(/password/i);
    this.loginButton = page.getByRole("button", { name: /login|sign in/i });
    this.dashboardMarker = page.getByTestId("dashboard");
  }

  async open(): Promise<void> {
    await this.page.goto("/login", { waitUntil: "domcontentloaded" });
  }

  async login(username: string, password: string): Promise<void> {
    await this.fill(this.usernameInput, username, "Username");
    await this.fill(this.passwordInput, password, "Password");
    await this.click(this.loginButton, "Login button");
  }

  async expectLoginSuccess(): Promise<void> {
    await expect(this.dashboardMarker).toBeVisible();
  }
}
