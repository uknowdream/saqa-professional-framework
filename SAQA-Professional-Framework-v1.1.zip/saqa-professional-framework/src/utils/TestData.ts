import { randomUUID } from "node:crypto";

export function uniqueEmail(prefix = "qa"): string {
  return `${prefix}.${randomUUID()}@example.test`;
}

export function uniqueString(prefix = "qa"): string {
  return `${prefix}-${randomUUID()}`;
}
