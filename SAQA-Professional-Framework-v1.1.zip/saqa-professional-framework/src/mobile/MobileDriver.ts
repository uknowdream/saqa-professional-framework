import { remote, type Browser } from "webdriverio";
import { getConfig } from "../core/Config.js";

export type MobilePlatform = "Android" | "iOS";

export class MobileDriver {
  private client?: Browser;

  async start(): Promise<Browser> {
    const config = getConfig();
    const platform = config.APPIUM_PLATFORM as MobilePlatform;

    const capabilities: Record<string, unknown> = {
      platformName: platform,
      "appium:automationName": platform === "Android" ? "UiAutomator2" : "XCUITest",
      "appium:deviceName": config.APPIUM_DEVICE_NAME,
      "appium:autoGrantPermissions": true,
      "appium:newCommandTimeout": 120
    };

    if (config.APPIUM_APP) {
      capabilities["appium:app"] = config.APPIUM_APP;
    }

    this.client = await remote({
      hostname: new URL(config.APPIUM_HOST).hostname,
      port: Number(new URL(config.APPIUM_HOST).port || 4723),
      path: new URL(config.APPIUM_HOST).pathname || "/",
      logLevel: "error",
      capabilities
    });

    return this.client;
  }

  async stop(): Promise<void> {
    if (this.client) {
      await this.client.deleteSession();
      this.client = undefined;
    }
  }

  getClient(): Browser {
    if (!this.client) {
      throw new Error("Mobile driver is not started.");
    }
    return this.client;
  }
}
