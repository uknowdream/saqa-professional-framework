import { test as base, expect } from "@playwright/test";
import { ApiClient } from "../api/ApiClient.js";

type Fixtures = {
  api: ApiClient;
};

export const test = base.extend<Fixtures>({
  api: async ({ request }, use) => {
    const baseUrl = process.env.API_BASE_URL ?? "https://example.com/api/";
    await use(new ApiClient(request, baseUrl));
  }
});

export { expect };
