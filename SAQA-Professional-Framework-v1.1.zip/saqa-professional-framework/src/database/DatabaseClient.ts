export interface DatabaseClient {
  query<T extends Record<string, unknown> = Record<string, unknown>>(
    sql: string,
    parameters?: readonly unknown[]
  ): Promise<T[]>;
  close(): Promise<void>;
}

/**
 * Adapter contract.
 * Implement PostgreSQL/MySQL/SQL Server/MongoDB adapters separately
 * using the database actually used by the application under test.
 */
export abstract class DatabaseAdapter implements DatabaseClient {
  abstract query<T extends Record<string, unknown>>(
    sql: string,
    parameters?: readonly unknown[]
  ): Promise<T[]>;

  abstract close(): Promise<void>;
}
