import { APIRequestContext, expect } from "@playwright/test";

export class ApiClient {
  constructor(
    private readonly request: APIRequestContext,
    private readonly baseUrl: string
  ) {}

  async get(path: string, options?: Parameters<APIRequestContext["get"]>[1]) {
    return this.request.get(new URL(path, this.baseUrl).toString(), options);
  }

  async post(
    path: string,
    data: unknown,
    options?: Parameters<APIRequestContext["post"]>[1]
  ) {
    return this.request.post(new URL(path, this.baseUrl).toString(), {
      ...options,
      data
    });
  }

  async put(
    path: string,
    data: unknown,
    options?: Parameters<APIRequestContext["put"]>[1]
  ) {
    return this.request.put(new URL(path, this.baseUrl).toString(), {
      ...options,
      data
    });
  }

  async delete(
    path: string,
    options?: Parameters<APIRequestContext["delete"]>[1]
  ) {
    return this.request.delete(new URL(path, this.baseUrl).toString(), options);
  }

  async expectStatus(response: Awaited<ReturnType<APIRequestContext["get"]>>, status: number) {
    expect(response.status()).toBe(status);
  }

  async expectJson(response: Awaited<ReturnType<APIRequestContext["get"]>>, expected: Record<string, unknown>) {
    const body = await response.json() as Record<string, unknown>;
    for (const [key, value] of Object.entries(expected)) {
      expect(body[key], `JSON property ${key}`).toEqual(value);
    }
  }
}
