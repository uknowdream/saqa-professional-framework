# SAQA Roadmap

## Phase 1 — Core
- Configuration
- Logging
- Error model
- Fixtures
- Web base page
- API client
- Evidence

## Phase 2 — Enterprise Web
- Page Object Model
- Component objects
- Authentication state
- Visual testing
- Accessibility
- Network mocking
- File testing

## Phase 3 — API
- Schema validation
- Contract tests
- Auth strategies
- Request builders
- Data cleanup

## Phase 4 — Database
- PostgreSQL adapter
- MySQL adapter
- SQL Server adapter
- transaction-safe cleanup

## Phase 5 — Mobile
- Android
- iOS
- native/hybrid
- deep links
- permissions
- gestures
- parallel devices

## Phase 6 — CI/CD
- GitHub Actions
- GitLab CI
- Docker
- sharding
- artifacts
- quality gates

## Phase 7 — Governance
- test ownership
- tagging
- flaky-test quarantine
- risk-based regression
- release gates
- test metrics
