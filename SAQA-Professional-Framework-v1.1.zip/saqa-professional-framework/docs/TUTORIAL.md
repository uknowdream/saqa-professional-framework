# SAQA Tutorial — From Zero to Professional QA Automation

## Step 1 — Install Node.js

Install Node.js 22 or newer.

Verify:

```bash
node -v
npm -v
```

## Step 2 — Clone the project

```bash
git clone https://github.com/uknowdream/saqa-professional-framework.git
cd saqa-professional-framework
```

## Step 3 — Install dependencies

```bash
npm install
npx playwright install
```

## Step 4 — Configure environment

Create `.env.staging` from `.env.example`.

Set the real staging URL:

```env
BASE_URL=https://staging.example.com
API_BASE_URL=https://api-staging.example.com
```

Never commit this file.

## Step 5 — Validate the framework

```bash
npm run quality
```

If this fails, fix framework/code-quality issues before adding application tests.

## Step 6 — Run the sample test

```bash
npm run test:e2e
```

Then:

```bash
npm run report
```

## Step 7 — Create your first real Page Object

Create:

```text
src/web/pages/LoginPage.ts
```

Put locators and reusable login actions there.

Then keep the test focused on behavior:

```typescript
await loginPage.open();
await loginPage.login(username, password);
await loginPage.expectLoginSuccess();
```

## Step 8 — Add test data

Do not put large data structures into test files.

Use:

```text
test-data/
```

For dynamic values, use utilities such as:

```typescript
uniqueEmail("registration");
```

## Step 9 — Add API tests

Create API service classes for business domains:

```text
src/api/services/
  AuthService.ts
  UserService.ts
  ProductService.ts
```

Then create tests:

```text
tests/api/
  auth.spec.ts
  users.spec.ts
  products.spec.ts
```

## Step 10 — Add database validation

Choose the database driver used by the application.

Implement the `DatabaseAdapter` contract in:

```text
src/database/
```

Keep SQL/database implementation outside the test cases.

## Step 11 — Add mobile

Install Appium and the platform driver.

Start:

```bash
npx appium server --address 127.0.0.1 --port 4723
```

Configure device/app values.

Create screen objects:

```text
src/mobile/screens/
  LoginScreen.ts
  HomeScreen.ts
  ProductScreen.ts
```

## Step 12 — Build suites

Recommended tags:

```text
@smoke
@sanity
@regression
@e2e
@api
@mobile
```

Examples:

```bash
npm run test:smoke
npm run test:regression
```

## Step 13 — CI

Push to GitHub.

Configure repository secrets.

The GitHub Actions workflow will:

1. Install dependencies.
2. Run typecheck.
3. Run lint.
4. Install browsers.
5. Execute tests.
6. Upload evidence.

## Step 14 — Professional defect investigation

If CI reports:

```text
FAIL
```

do not immediately add a retry.

Check:

1. Screenshot.
2. Trace.
3. Video.
4. Console.
5. Network.
6. Test data.
7. Environment.
8. Application logs if available.

Then classify the failure.

## Step 15 — Production readiness checklist

Before calling the framework production-ready:

- [ ] TypeScript strict passes.
- [ ] Lint passes.
- [ ] Tests are deterministic.
- [ ] No credentials in Git.
- [ ] Test data is isolated.
- [ ] Authentication is reusable and secure.
- [ ] Database cleanup is safe.
- [ ] API contracts are validated.
- [ ] Mobile capabilities are explicit.
- [ ] CI quality gates exist.
- [ ] Failure artifacts are retained.
- [ ] Flaky tests are tracked.
- [ ] Critical business flows have regression coverage.
- [ ] Code review is required.
