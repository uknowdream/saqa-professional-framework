# Test Design Standard

## Test levels

- Smoke: critical path and environment health.
- Sanity: focused verification of a change.
- Regression: stable business-critical suite.
- E2E: cross-layer business flow.
- API: endpoint behavior and contract.
- Mobile: native/hybrid/device-specific behavior.

## Required test anatomy

Every automated test should have:

1. A unique test ID.
2. A business-readable title.
3. Deterministic setup.
4. One clear behavior under test.
5. Explicit assertions.
6. Useful failure evidence.
7. Independent cleanup.

## Locator policy

Preferred:

1. `getByRole`
2. `getByLabel`
3. `getByTestId`
4. stable CSS/data attributes

Avoid:

- generated CSS classes
- deep XPath
- nth-child selectors
- arbitrary sleeps

## Retry policy

Retries are for infrastructure/transient failures, not for hiding product defects. A repeatedly failing test must be investigated and classified as product defect, environment issue, or test defect.
