# SAQA Professional QA Automation Framework

**SAQA (Saiful QA Automation)** is a professional QA automation framework foundation designed for Web, API, Mobile and Database testing.

> This repository is a reusable engineering foundation. It is not a universal "one-click tester": every application still needs its own locators, business rules, API contracts, test data, device capabilities and environment configuration.

## 1. Technology Stack

| Area | Technology |
|---|---|
| Language | TypeScript |
| Web | Playwright |
| API | Playwright APIRequestContext |
| Mobile | Appium + WebdriverIO |
| Test Runner | Playwright Test |
| Validation | Playwright Expect + Zod |
| Code Quality | TypeScript strict + ESLint + Prettier |
| CI/CD | GitHub Actions |
| Container | Docker |

## 2. Architecture

```text
                         SAQA
                          |
              +-----------+-----------+
              |           |           |
             WEB         API        MOBILE
              |           |           |
         Playwright    API Layer   Appium
              |                       |
       +------+------+            +---+---+
       |      |      |            |       |
    Chrome  Edge  Firefox      Android   iOS

                    |
                DATABASE
                    |
             DB Adapter Layer

                    |
                 CI/CD
                    |
              GitHub Actions
```

## 3. Project Structure

```text
saqa-professional-framework/
├── .github/workflows/qa.yml
├── docker/Dockerfile
├── docs/
│   ├── ROADMAP.md
│   └── TEST-DESIGN.md
├── src/
│   ├── api/
│   ├── core/
│   ├── database/
│   ├── fixtures/
│   ├── mobile/
│   ├── utils/
│   └── web/
├── tests/
│   ├── api/
│   ├── e2e/
│   ├── mobile/
│   └── web/
├── test-data/
├── .env.example
├── eslint.config.js
├── package.json
├── playwright.config.ts
├── tsconfig.json
└── README.md
```

## 4. Requirements

Recommended:

- Node.js 22+
- npm 10+
- Git
- VS Code or another TypeScript IDE
- Android Studio + Android SDK for Android automation
- Xcode for iOS automation (macOS required)
- Appium for mobile automation

Verify Node:

```bash
node --version
npm --version
git --version
```

## 5. Installation

Clone the repository:

```bash
git clone https://github.com/uknowdream/saqa-professional-framework.git
cd saqa-professional-framework
```

Install dependencies:

```bash
npm install
```

Install Playwright browsers:

```bash
npx playwright install
```

On Linux CI:

```bash
npx playwright install --with-deps
```

## 6. Environment Configuration

Copy:

```text
.env.example
```

to an environment file, for example:

```text
.env.staging
```

Example:

```env
TEST_ENV=staging
BASE_URL=https://your-staging-app.example.com
API_BASE_URL=https://your-staging-api.example.com
HEADLESS=true

TEST_USERNAME=
TEST_PASSWORD=

DB_HOST=
DB_PORT=
DB_NAME=
DB_USER=
DB_PASSWORD=

APPIUM_HOST=http://127.0.0.1:4723
APPIUM_PLATFORM=Android
APPIUM_DEVICE_NAME=
APPIUM_APP=
```

### Security rule

Never commit:

```text
.env
.env.staging
.env.production
passwords
tokens
private keys
API secrets
```

Only `.env.example` belongs in Git.

## 7. Validate the Framework Before Testing an Application

Run:

```bash
npm run typecheck
npm run lint
npm run format:check
```

Or:

```bash
npm run quality
```

This checks the framework itself before application tests are executed.

## 8. Run Web Tests

All tests:

```bash
npm test
```

Web only:

```bash
npm run test:web
```

Smoke:

```bash
npm run test:smoke
```

Regression:

```bash
npm run test:regression
```

E2E:

```bash
npm run test:e2e
```

Interactive UI:

```bash
npm run test:ui
```

Debug mode:

```bash
npm run test:debug
```

Open HTML report:

```bash
npm run report
```

## 9. Web Test Design

Use stable, user-oriented locators.

Preferred order:

1. `getByRole`
2. `getByLabel`
3. `getByTestId`
4. stable data attributes
5. stable CSS selectors only when necessary

Avoid:

```typescript
await page.waitForTimeout(5000);
```

Prefer condition-based synchronization:

```typescript
await expect(page.getByTestId("dashboard")).toBeVisible();
```

Do not write selectors such as generated CSS classes or fragile `nth-child()` chains unless there is no stable alternative.

## 10. Page Object Model

A test should describe business behavior, not implementation details.

Instead of:

```typescript
await page.locator("#username").fill("admin");
await page.locator("#password").fill("secret");
await page.locator("#login").click();
```

prefer:

```typescript
await loginPage.login(username, password);
await loginPage.expectLoginSuccess();
```

The locator implementation belongs in the Page Object.

## 11. API Testing

The API client is located at:

```text
src/api/ApiClient.ts
```

Example:

```typescript
const response = await api.post("/users", {
  name: "QA User",
  email: "qa@example.test"
});

expect(response.status()).toBe(201);
```

API tests should verify:

- HTTP status
- response body
- required properties
- data types
- business rules
- authentication/authorization
- negative cases
- error response
- headers where relevant

The next framework phase should add formal schema/contract validation.

## 12. Mobile Testing

Start Appium:

```bash
npx appium server --address 127.0.0.1 --port 4723
```

Check installed drivers:

```bash
npm run mobile:doctor
```

Android requires an installed Appium Android driver, Android SDK and a connected emulator/device.

iOS requires macOS + Xcode + an iOS simulator/device and the Appium XCUITest driver.

Set:

```env
RUN_MOBILE=true
APPIUM_HOST=http://127.0.0.1:4723
APPIUM_PLATFORM=Android
APPIUM_DEVICE_NAME=your-device
APPIUM_APP=/absolute/path/to/app.apk
```

Then:

```bash
npx playwright test tests/mobile
```

## 13. Database Testing

`src/database/DatabaseClient.ts` defines the adapter contract.

Do not put database-specific code directly into tests.

Recommended architecture:

```text
Test
 |
DatabaseClient
 |
+-- PostgreSQLAdapter
+-- MySQLAdapter
+-- SqlServerAdapter
+-- MongoAdapter
```

The correct driver depends on the application's actual database.

Database validation should normally be used for:

- persistence verification
- cleanup
- test data setup
- cross-layer consistency

Do not use database access to bypass the behavior you are supposed to test.

## 14. Test IDs and Tags

Use unique business-oriented IDs:

```text
AUTH-001
AUTH-002
USER-001
PRODUCT-001
ORDER-001
PAYMENT-001

API-AUTH-001
API-USER-001

MOB-AUTH-001
MOB-CART-001
```

Example:

```typescript
test("AUTH-001 - valid login @smoke @regression", async () => {});
```

## 15. Test Quality Rules

Every automated test should have:

1. Unique ID.
2. Business-readable name.
3. Deterministic setup.
4. One clear behavior under test.
5. Explicit assertions.
6. Failure evidence.
7. Independent cleanup.

Important:

- Do not use retries to hide product defects.
- Do not use arbitrary sleeps for synchronization.
- Do not share mutable state between tests.
- Do not hard-code credentials.
- Do not make tests dependent on execution order.
- Treat flaky tests as defects in the test suite until proven otherwise.

## 16. Evidence

Playwright is configured to retain:

- screenshot on failure
- video on failure
- trace on failure
- HTML report

Artifacts are stored under Playwright's test-result/report directories.

When a test fails, investigate the evidence before changing the test.

## 17. CI/CD

GitHub Actions workflow:

```text
.github/workflows/qa.yml
```

Pipeline:

```text
Checkout
   |
Install Node
   |
npm ci
   |
Typecheck
   |
Lint
   |
Install browsers
   |
Run tests
   |
Upload evidence
```

Required GitHub Secrets should be configured in:

```text
Repository Settings
→ Secrets and variables
→ Actions
```

Never place secrets directly in the workflow YAML.

## 18. Docker

Build:

```bash
docker build -f docker/Dockerfile -t saqa .
```

Run:

```bash
docker run --rm saqa
```

Real projects should inject environment variables/secrets at runtime rather than baking credentials into the image.

## 19. Development Workflow

Recommended professional workflow:

```text
Requirement
    ↓
Risk analysis
    ↓
Test case design
    ↓
Test data
    ↓
Automation implementation
    ↓
Local validation
    ↓
Code review
    ↓
CI
    ↓
Evidence analysis
    ↓
Defect / test defect classification
    ↓
Merge
```

## 20. Failure Classification

When a test fails, classify it before changing code:

```text
PRODUCT DEFECT
ENVIRONMENT FAILURE
TEST DATA FAILURE
AUTOMATION DEFECT
FLAKY TEST
INFRASTRUCTURE FAILURE
```

Do not automatically modify the assertion or add retries just to make CI green.

## 21. Roadmap

### Phase 1 — Foundation
- Configuration
- logging
- fixtures
- error model
- Web Page Objects
- API client
- evidence

### Phase 2 — Enterprise Web
- reusable components
- authentication state
- network mocking
- file testing
- visual regression
- accessibility

### Phase 3 — API
- schema validation
- contract testing
- auth strategies
- request builders
- cleanup

### Phase 4 — Database
- PostgreSQL
- MySQL
- SQL Server
- transaction-safe cleanup

### Phase 5 — Mobile
- Android
- iOS
- native/hybrid
- deep links
- permissions
- gestures
- parallel devices

### Phase 6 — CI/CD
- Docker
- sharding
- artifacts
- quality gates
- release gates

### Phase 7 — Enterprise Governance
- ownership
- tagging
- flaky-test quarantine
- risk-based regression
- metrics
- release quality gates

## 22. Important Limitation

No QA automation framework can honestly guarantee "zero bugs".

The engineering objective is:

```text
High reliability
+
Deterministic tests
+
Strong assertions
+
Good isolation
+
Traceable evidence
+
Secure configuration
+
Fast failure diagnosis
+
CI quality gates
```

A framework should **fail safely and visibly**, never silently convert an automation error into a false PASS.

## 23. Recommended Next Implementation

Before using this framework on a real company project, implement the following in order:

1. Real application Page Objects.
2. Authentication/session fixture.
3. API authentication.
4. Schema validation.
5. Database adapter for the application's DB.
6. Test-data factory.
7. Cleanup strategy.
8. Mobile screen objects.
9. Accessibility checks.
10. Visual regression.
11. CI quality gates.
12. Flaky-test management.
13. Security/secret scanning.
14. Full enterprise reporting.

This keeps the framework maintainable instead of becoming a collection of fragile scripts.
